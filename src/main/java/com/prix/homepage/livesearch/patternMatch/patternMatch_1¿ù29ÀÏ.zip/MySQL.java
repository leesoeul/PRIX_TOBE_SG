/************************************************************
 * File: MySQL.java											*
 * Last modified on The Jan 15 2007							*
 * -------------------------------------------------------- *
 * MySQL�� �����Ͽ� ���ǿ� ���� �˻��� ����� �����ش�.			*
 *  4���� ���												*
 * 1) species�� �Էµǰ�, Swiss_prot DB���� �˻�				*
 * 2) no species,		Swiss_prot DB						*
 * 3) species, 			Genbank								*
 * 4) no species, 		Genbank								*
 * ���� ������ �ԷµǾ��� ��(p1, p2, ...) 						*
 * ������� ã�� ��� (order==true) p1.*p2�� �˻��� �Ѵ�. 		*
 * (.�� ������ ���ڸ� *�� ���� �ܾ 0�� Ȥ�� ������ ������ �ǹ�)*
 * ������� ã�� �ʴ� ��쿡�� (order==false)					*
 * sequence rlike 'p1' && sequence rlike 'p2'�� �˻��Ѵ�.		* 
 *                   Mechanical Information Engineering   	*
 *		                     2004430007 Kim Won-Kyoung    	*
 ***********************************************************/

package patternMatch;
import java.sql.*;

public class MySQL {
	private String id, passwd, db, ip;
	private Connection con;
	private Statement stmt;

	public MySQL(String id, String passwd, String ip, String db) {
		this.id = id;
		this.passwd = passwd;
		this.ip = ip;
		this.db = db;
		try {
			Class.forName("org.gjt.mm.mysql.Driver").newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void Connect() {
		try{
			String url = "jdbc:mysql://" + ip + db;
			con = DriverManager.getConnection(url, id, passwd);
			stmt = con.createStatement();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	// species�� �Է� �Ǿ����� swiss prot DB
	public ResultSet Swiss_protSequence(String species, String[] inputPattern, boolean order) throws SQLException{
		int many = inputPattern.length;

		StringBuffer stmtBuffer = new StringBuffer();
		// ���� ���̺��� join ���Ѽ� ���ϴ� species�� pattern�� �´� data�� �о�´� 
		// String��  '+'operating �ϴ°� ���� StringBuffer�� append()�ϴ°� �� ȿ������.
		stmtBuffer.append("select ac_to_species.primary_ac, description, species, sequence");
		stmtBuffer.append(" from ac_to_species, sequence_data, extra_information");
		stmtBuffer.append(" where ac_to_species.primary_ac = sequence_data.primary_ac");
		stmtBuffer.append(" && ac_to_species.primary_ac = extra_information.primary_ac ");
	
		if (order){
			stmtBuffer.append("&& sequence rlike '");
			for (int i=0; i<many; i++){
				stmtBuffer.append(inputPattern[i]);
				if (i != many-1)
					stmtBuffer.append(".*");
			}
			stmtBuffer.append("'");
		}
		
		else{
			for (int i=0; i<many; i++){
				stmtBuffer.append("&& sequence rlike '");				
				stmtBuffer.append(inputPattern[i]);
				stmtBuffer.append("'");
			}
		}
			
		stmtBuffer.append(" && species like '");
		stmtBuffer.append(species);
		stmtBuffer.append("%';");
	
		return stmt.executeQuery(stmtBuffer.toString());
	}	
	
/*	
	// species�� �Է� �Ǿ����� swiss prot DB
	public ResultSet Swiss_protSequence(String species, String[] inputPattern, boolean order){
		int many = inputPattern.length;
		String a="desc sequence_data;";
System.out.println("�١ڡ�");		
		ResultSet rs=null;
		try {
			rs = stmt.executeQuery(a);
			System.out.println("�١�");
			rs.next();String name = rs.getString(1);String id = rs.getString(2);System.out.println(name + "\t" + id);
			System.out.println("�١ڡڡ�");
			return rs;
		} catch (SQLException e) {
			System.out.println("��######");
			e.printStackTrace();
		}
		return rs;
		 
		StringBuffer stmtBuffer = new StringBuffer();
		// ���� ���̺��� join ���Ѽ� ���ϴ� species�� pattern�� �´� data�� �о�´� 
		// String��  '+'operating �ϴ°� ���� StringBuffer�� append()�ϴ°� �� ȿ������.
		stmtBuffer.append("select ac_to_species.primary_ac, description, species, sequence");
		stmtBuffer.append(" from ac_to_species, sequence_data, extra_information");
		stmtBuffer.append(" where ac_to_species.primary_ac = sequence_data.primary_ac");
		stmtBuffer.append(" && ac_to_species.primary_ac = extra_information.primary_ac ");
	
		if (order){
			stmtBuffer.append("&& sequence rlike '");
			for (int i=0; i<many; i++){
				stmtBuffer.append(inputPattern[i]);
				if (i != many-1)
					stmtBuffer.append(".*");
			}
			stmtBuffer.append("'");
		}
		
		else{
			for (int i=0; i<many; i++){
				stmtBuffer.append("&& sequence rlike '");				
				stmtBuffer.append(inputPattern[i]);
				stmtBuffer.append("'");
			}
		}
			
		stmtBuffer.append(" && species like '");
		stmtBuffer.append(species);
		stmtBuffer.append("%';");
System.out.println(stmtBuffer.toString());
		return stmt.executeQuery(stmtBuffer.toString());
	}*/
	
	// species�� �Է� ���� �ʾ����� swiss prot DB
	public ResultSet Swiss_protSequence(String[] inputPattern, boolean order) throws SQLException{
		int many = inputPattern.length;
		StringBuffer stmtBuffer = new StringBuffer();
		// species�� �Էµ������� ũ�� �ٸ��� ����
		stmtBuffer.append("select ac_to_species.primary_ac, description, species, sequence");
		stmtBuffer.append(" from ac_to_species, sequence_data, extra_information");
		stmtBuffer.append(" where ac_to_species.primary_ac = sequence_data.primary_ac");
		stmtBuffer.append(" && ac_to_species.primary_ac = extra_information.primary_ac");
	
		if (order){
			stmtBuffer.append("	&& sequence rlike '");
			for (int i=0; i<many; i++){
				stmtBuffer.append(inputPattern[i]);
				if (i != many-1)
					stmtBuffer.append(".*");
			}
			stmtBuffer.append("';");
		}
		
		else{
			for (int i=0; i<many; i++){
				stmtBuffer.append("	&& sequence rlike '");				
				stmtBuffer.append(inputPattern[i]);
				stmtBuffer.append("'");
			}
			stmtBuffer.append(";");			
		}
		return stmt.executeQuery(stmtBuffer.toString());
	}
	
	// species�� �ԷµǾ����� genbank DB 
	public ResultSet GenbankSequence(String species, String[] inputPattern, boolean order) throws SQLException{
		int many = inputPattern.length;

		StringBuffer stmtBuffer = new StringBuffer();
		stmtBuffer.append("select * from general_info where species = '");
		stmtBuffer.append(species);
		stmtBuffer.append("'");
		
		if (order){
			stmtBuffer.append("	&& sequence rlike '");
			for (int i=0; i<many; i++){
				stmtBuffer.append(inputPattern[i]);
				if (i != many-1 )
					stmtBuffer.append(".*");
			}
			stmtBuffer.append("'");
		}
		
		else{
			for (int i=0; i<many; i++){
				stmtBuffer.append("	&& sequence rlike '");				
				stmtBuffer.append(inputPattern[i]);
				stmtBuffer.append("'");
			}
		}
		
		stmtBuffer.append(";");
	
		return stmt.executeQuery(stmtBuffer.toString());
	}
	
	// species�� �Է� ���� �ʾ����� genbank DB
	public ResultSet GenbankSequence(String[] inputPattern, boolean order) throws SQLException{
		int many = inputPattern.length;

		StringBuffer stmtBuffer = new StringBuffer();
		stmtBuffer.append("select * from general_info");

		if (order){
			stmtBuffer.append(" where sequence rlike '");
			for (int i=0; i<many; i++){
				stmtBuffer.append(inputPattern[i]);
				if (i != many-1 )
					stmtBuffer.append(".*");
			}
			stmtBuffer.append("'");
		}
		
		else{
			for (int i=0; i<many; i++){
				if (i==0)
					stmtBuffer.append(" where sequence rlike '");
				else
					stmtBuffer.append(" && sequence rlike '");
				stmtBuffer.append(inputPattern[i]);
				stmtBuffer.append("'");
			}
		}
		
		stmtBuffer.append(";");
		
		return stmt.executeQuery(stmtBuffer.toString());
	}
	
	public void Close(){
		try {
			stmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}